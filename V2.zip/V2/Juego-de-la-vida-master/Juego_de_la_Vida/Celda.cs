﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

namespace Juego_de_la_Vida
{
    public class Celda
    {

        public int alive = 0;

        //Constructor
        public Celda( int vive)
        {
            this.alive = vive;
        }
        public int isAlive()
        {
            return this.alive;
        }
        public void setAlive()
        {
            this.alive = 1;
        }
    }



}
