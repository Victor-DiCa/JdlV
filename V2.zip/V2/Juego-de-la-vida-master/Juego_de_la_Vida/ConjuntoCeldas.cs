﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juego_de_la_Vida
{
   public class ConjuntoCeldas
    {
        public Celda[,] celdas;

        public ConjuntoCeldas(int filas, int columnas)
        {
            this.celdas = new Celda[filas, columnas];
            for (int i =0;i<filas;i++)
            {
                for (int j= 0; j < filas; j++)
                {
                    celdas[i, j] = new Celda(0);
                }
            }

        }

        public int compararCeldas(int i, int j, int maxFilas, int maxColumnas)
        {
            int sum;
            
            if (i != 0 && j == 0 && i != maxFilas)                              //Celdas contiguas al eje horizontal
                sum = celdas[i + 1, j].alive + celdas[i + 1, j + 1].alive + celdas[i - 1, j].alive + celdas[i - 1, j + 1].alive + celdas[i, j + 1].alive;
            else if (i == 0 && j != 0 && j != maxColumnas)                      //Celdas contiguas al eje vertical
                sum = celdas[i + 1, j].alive + celdas[i + 1, j + 1].alive + celdas[i + 1, j - 1].alive + celdas[i, j - 1].alive + celdas[i, j + 1].alive;
            else if (i == 0 && j == 0)                                          //Celda vértice superior izquierdo (0,0)
                sum = celdas[i + 1, j].alive + celdas[i + 1, j + 1].alive + celdas[i, j + 1].alive;
            else if (j != 0 && i == maxFilas && j != maxColumnas)               //Celdas contiguas al eje de máximo valor horizontal
                sum = celdas[i - 1, j].alive + celdas[i - 1, j - 1].alive + celdas[i - 1, j + 1].alive + celdas[i, j - 1].alive + celdas[i, j + 1].alive;
            else if (i != 0 && i != maxFilas && j == maxColumnas)               //Celdas contiguas al eje de máximo valor vertical
                sum = celdas[i + 1, j].alive + celdas[i + 1, j - 1].alive + celdas[i - 1, j].alive + celdas[i - 1, j - 1].alive + celdas[i, j - 1].alive;
            else if (i == 0 && j == maxColumnas)                                //Celda vértice superior derecho (0,max)
                sum = celdas[i + 1, j].alive + celdas[i + 1, j - 1].alive + celdas[i, j - 1].alive;
            else if (i != 0 && j != 0 && i != maxFilas && j != maxColumnas)     //Celda vértice inferior izquierdo(max,0)
                sum = celdas[i - 1, j].alive + celdas[i - 1, j + 1].alive + celdas[i, j + 1].alive;
            else if (i != 0 && j != 0 && i != maxFilas && j != maxColumnas)     //Celda vértice inferior derecho(max,max)
                sum = celdas[i - 1, j].alive + celdas[i - 1, j - 1].alive + celdas[i, j - 1].alive;
            else                                                                //Celdas interiores de la malla
                sum = celdas[i + 1, j].alive + celdas[i + 1, j + 1].alive + celdas[i + 1, j - 1].alive + celdas[i - 1, j].alive + celdas[i - 1, j - 1].alive + celdas[i - 1, j + 1].alive + celdas[i, j - 1].alive + celdas[i, j + 1].alive;
            return sum;
        }
    }
}
