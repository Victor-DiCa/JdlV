﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pruebas
{
    public partial class Form1 : Form
    {
        //Entorno entorno = new Entorno();
        //int dimensionesEntorno = 450;
                        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Entorno entorno= new Entorno(trackBar1.Value, pictureBox1.Width);
            entorno.setNumeroCelulas(trackBar1.Value);
            pintarEntorno(pictureBox1.Width, trackBar1.Value, entorno, Color.White);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        public class Celula
        {
            int estado;
            //string color;
            //string nombre;
            double tamaño;


            public Celula(int estado, double tamaño)
            {
                this.estado = estado;
                //this.color = color;
                //this.nombre = nombre;
                this.tamaño = tamaño;
            }
            public Celula()
            {
                this.estado = 0;
                this.tamaño = 30;
            }

            public bool getEstado()
            {
                if (this.estado == 0)
                    return false;
                else
                    return true;
            }

        }
        public class Entorno
        {
            Celula[,] entornoCelulas;
            int numeroCelulas;
            
            public Entorno(int numeroCelulas, int dimensionesEntorno)
            {
                
                int i = 0;
                while (i<numeroCelulas)

                {
                    int j = 1;
                    while (j < numeroCelulas)
                    {
                        i = 0;
                        Celula nuevaCelula = new Celula(0, dimensionesEntorno/numeroCelulas);
                        this.entornoCelulas[i, j] = nuevaCelula;
                        j = j + 1;
                    }
                    i = i + 1;
                }
            }
            public void setNumeroCelulas(int numeroCelulas)
            {
                this.numeroCelulas = numeroCelulas;
            }
            public Celula getCelula(int i, int j)
            {
                return (this.entornoCelulas[i,j]);
            }
        }

        public void pintarEntorno(int tamañoEntorno, int numeroCelulas, Entorno entorno, Color color)
        {
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            //Celula activo = new Celula();
            int i = 0;
            while (i<tamañoEntorno)
            {
                int j = 0;
                while (j < tamañoEntorno)
                {
                    //activo = entorno.getCelula(i, j);

                    if (!entorno.getCelula(i,j).getEstado())
                    {
                        pintarCelulas(bmp, i, j, tamañoEntorno/numeroCelulas, Color.Black);
                    }
                    else
                    {
                        pintarCelulas(bmp, i, j, tamañoEntorno/numeroCelulas, color);
                    }
                }

            }
        }
        private void pintarCelulas(Bitmap bmp, int x, int y, int tamañoCelula, Color color)
        {
            int i = 0;
            while (i< tamañoCelula)
            {
                int j = 0;
                while (j< tamañoCelula)
                {
                    bmp.SetPixel(i + (x * tamañoCelula), j + (y * tamañoCelula), color);
                    y = y + 1;
                }
                i = i + 1;
            }
        }

    }
}
